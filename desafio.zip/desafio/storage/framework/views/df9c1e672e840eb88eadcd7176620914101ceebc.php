﻿<!DOCTYPE html>
<html>
<head>
<title><?php echo e($title ?? 'Sem Título'); ?></title>

<!-- bootstrap -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="<?php echo e(url('assets/product/css/style.css')); ?>" >
</head>

<body>

<header>

</header>

<div class="container">
  <?php echo $__env->yieldContent('content'); ?> <!-- Toda tag do Blade Laravel começa com '@' --><!-- @ yield('content') comando laravel qeu indica variavel que vai receber itens de outros arquivos  -->
</div>

<footer>

</footer>

</body>
</html>
<?php /**PATH C:\wamp64\www\Laravel\desafio\resources\views/templates/template.blade.php ENDPATH**/ ?>