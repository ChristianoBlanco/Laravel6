<?php $__env->startSection('content'); ?>

<h1 class="title-pg">
<a href="<?php echo e(route('produto.index')); ?>"> << </a>    Produto: <?php echo e($produto->nome); ?></h1>

<table width="476" border="0" cellspacing="0" cellpadding="0" class="table table-striped">
    <tr>
      <th>Nome</th>
      <th>Marca</th>
      <th>Preço</th>
      <th>Categoria</th>
      <th>Qtd.</th>

    </tr>

    <tr>
      <td><?php echo e($produto->nome); ?></td>
      <td><?php echo e($produto->marca); ?></td>
      <td><?php echo e($produto->preco); ?></td>
      <td><?php echo e($produto->categoria); ?></td>
      <td><?php echo e($produto->qtd); ?></td>
    </tr>

  </table>
  <p><b>Descrição:</b><br><?php echo e($produto->descricao); ?></p>

  <br>
  <hr>
  <?php if(isset($errors) && count($errors) > 0): ?>

     <div class="alert alert-danger">
       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p><?php echo e($error); ?></p>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>

  <?php endif; ?>
  <?php echo Form::open(['route' =>['produto.destroy', $produto->id_produto], 'method' =>'DELETE']); ?>

      <?php echo Form::submit("Deletar produto $produto->nome", ['class' => 'btn btn-danger']); ?>

  <?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel\desafio\resources\views/product/show.blade.php ENDPATH**/ ?>