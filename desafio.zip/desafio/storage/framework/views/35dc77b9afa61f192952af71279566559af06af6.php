﻿

<?php $__env->startSection('content'); ?>

  <table width="476" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <th>Nome</th>
    <th>Marca</th>
    <th>Preço</th>
    <th>Qtd.</th>
    <th>Ações</th>
  </tr>

  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td>

    </td>
  </tr>

</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel\desafio\resources\views/product/lista.blade.php ENDPATH**/ ?>