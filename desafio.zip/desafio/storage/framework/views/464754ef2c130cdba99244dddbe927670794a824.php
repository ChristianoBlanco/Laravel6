﻿

<?php $__env->startSection('content'); ?>

<h1 class="title-pg">Produtos</h1>

<a href="<?php echo e(route('produto.create')); ?>" class="btn btn-btn btn-primary btn-add">
  Cadastrar
</a>
<br><br>
<form action="<?php echo e(route('search')); ?>" method="POST" class="form form-inline">
    <?php echo e(csrf_field()); ?>

   <input type="text" name='marca' class="form-control" placeholder="Pesquisar Marca...">

   <button type="submit" class="btn btn-primary">Pesquisar</button>
</form>

  <table width="476" border="0" cellspacing="0" cellpadding="0" class="table table-striped">
  <tr>
    <th>Nome</th>
    <th>Marca</th>
    <th>Preço</th>
    <th>Categoria</th>
    <th>Qtd.</th>
    <th width="100px">Ações</th>
  </tr>
  <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($produto->nome); ?></td>
    <td><?php echo e($produto->marca); ?></td>
    <td><?php echo e($produto->preco); ?></td>
    <td><?php echo e($produto->categoria); ?></td>
    <td><?php echo e($produto->qtd); ?></td>
    <td>
    <a href="<?php echo e(route('produto.edit', $produto->id_produto)); ?>" class="actions edit">
         <span class="glyphicon glyphicon-pencil">Edt </span>
     </a>

     <a href="<?php echo e(route('produto.show', $produto->id_produto)); ?>" class="actions delete">
            <span class="glyphicon glyphicon-trash"> Del</span>
     </a>
    </td>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </td>
  </tr>

</table>

<?php echo $produtos->links(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel\desafio\resources\views/product/index.blade.php ENDPATH**/ ?>