﻿

<?php $__env->startSection('content'); ?>
<h1 class="title-pg">
        <a href="<?php echo e(route('produto.index')); ?>"> << </a>
    Gestão Produto</h1>
  <br>
  <?php if(isset($errors) && count($errors) > 0): ?>

     <div class="alert alert-danger">
       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p><?php echo e($error); ?></p>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>

  <?php endif; ?>
  <br>
  <?php if(isset($produto->id_produto)): ?>
  <form class="form" method="POST" action="<?php echo e(route('produto.update', $produto->id_produto)); ?>">
    <?php echo method_field('PUT'); ?>

  <?php else: ?>
  <form class="form" method="POST" action="<?php echo e(route('produto.store')); ?>">
  <?php endif; ?>
<?php echo csrf_field(); ?>

      <div class="form-group">
      <input type="text" name="nome"      placeholder="Nome" class="form-control" value="<?php echo e($produto->nome ?? old('nome')); ?>">
      </div>
      <div class="form-group">
        <input type="text" name="marca"     placeholder="Marca" class="form-control" value="<?php echo e($produto->marca ?? old('marca')); ?>">
      </div>
      <div class="form-group">
         <input type="text" name="preco"     placeholder="Preço" class="form-control" value="<?php echo e($produto->preco ?? old('preco')); ?>">
      </div>
      <div class="form-group">
         <input type="text" name="qtd"       placeholder="Qtd" class="form-control" value="<?php echo e($produto->qtd ?? old('qtd')); ?>">
      </div>
      <div class="form-group">
      <select name="categoria" class="form-control">
          <option>Escolha a categoria</option>
          <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($categoria); ?>"
         <?php if(isset($produto) && $produto->categoria == $categoria): ?>
             selected
         <?php endif; ?>
         ><?php echo e($categoria); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      </div>
      <div class="form-group">
      <textarea name="descricao"  placeholder="Descrição" class="form-control" value="<?php echo e($produto->descricao ?? old('descricao')); ?>"><?php echo e($produto->descricao ?? old('descricao')); ?></textarea>
      </div>
      <br>
      <button class="btn btn-primary">Enviar</button>
  </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel\desafio\resources\views/product/cadastra-edita.blade.php ENDPATH**/ ?>