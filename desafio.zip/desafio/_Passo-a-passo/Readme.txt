1 - Insatalar ultima versão do Laravel;
2 - Copiar a pasta "desafio" para dentro do serviço web (eu usei o WAMP 3.1);
3 - Criar banco de dados no SQL e rodar as migrations dentro da pasta Migration;
4 - Acessar a pasta pelo browser do serviço web ("desafio/public/") e rodar o teste.

<title>{{ $title ?? 'Sem Título'}}</title>


