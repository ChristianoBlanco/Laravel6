<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\produto;

class ProdutoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $product;
    private $totalPage = 5;

    public function __construct(Produto $product)
    {
        $this->produto = $product;
    }
    public function index(Produto  $produto)
    {
       $title = 'Desafio Laravel';
       //$produtos =  $produto->all();
       $produtos =  $produto->paginate($this->totalPage);

       return view('product.index', compact('produtos','title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Cadastrar novo produto';

        $categorias = ['nivel1','nivel2','nivel3'];

        return view('product.cadastra-edita', compact('title','categorias'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $dataForm = $request->all();

        $this->validate($request, $this->produto->rules);

        $insert = $this->produto->create($dataForm);

        if($insert){
            return redirect()->route('produto.index');
        }else{
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $produto = $this->produto->find($id);

        !empty($produto->nome) ? $title = 'Editar produto: '.$produto->nome : $title = 'Editar produto:';

        return view('product.show', compact('produto', 'title'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $produto = $this->produto->find($id);

        $title = 'Editar produto: '.$produto->nome;

        $categorias = ['nivel1','nivel2','nivel3'];

        return view('product.cadastra-edita', compact('title','categorias', 'produto'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $dataForm = $request->all();

        $this->validate($request, $this->produto->rules);

        $produto = $this->produto->find($id);

        $update = $produto->update($dataForm);

        if($update){
            return redirect()->route('produto.index');
        }else{
            return redirect()->route('produto.edit')->with(['errors' => 'Falha ao Editar']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $produto = $this->produto->find($id);

        $delete = $produto->delete();
        if($delete){
            return redirect()->route('produto.index');
        }else{
            return redirect()->route('produto.show')->with(['errors' => 'Falha ao Deletar']);
        }
    }

    public function searchMarca(Request $request, Produto $produto ){

        //dd($request->all());
        $dataForm = $request->all();

        $produtos = $produto->search($dataForm, $this->totalPage);

        return view('product.index', compact('produtos'));

    }
}
