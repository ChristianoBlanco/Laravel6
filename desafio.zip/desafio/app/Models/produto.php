<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class produto extends Model
{

 private $totalPage = 5;

  protected $table = 'produtos';

  protected $primaryKey = 'id_produto';

  protected $guarded = array('id_produto');

  protected $fillable = ['nome', 'marca', 'preco', 'qtd', 'categoria', 'descricao'];

  public $rules = [
      'nome'      => 'required|min:3|max:100',
      'marca'     => 'required|min:3|max:100',
      'preco'     => 'required',
      'qtd'       => 'required|numeric',
      'categoria' => 'required',
      'descricao' => 'min:3|max:100'

  ];

  public function search(Array $produto, $totalPage){

    return $this->where(function($query) use ($produto){

       if(isset($produto['marca'])){
           $query->where('marca', $produto['marca']);
       }


    })->paginate($totalPage);
    //->toSql();dd($produto);

  }
}
