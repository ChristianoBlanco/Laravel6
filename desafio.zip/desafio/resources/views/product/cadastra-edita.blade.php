﻿@extends('layouts.app')

@section('content')
<h1 class="title-pg">
        <a href="{{route('produto.index')}}"> << </a>
    Gestão Produto</h1>
  <br>
  @if(isset($errors) && count($errors) > 0)

     <div class="alert alert-danger">
       @foreach ($errors->all() as $error )
          <p>{{$error}}</p>
       @endforeach
     </div>

  @endif
  <br>
  @if (isset($produto->id_produto))
  <form class="form" method="POST" action="{{route('produto.update', $produto->id_produto)}}">
    {!! method_field('PUT') !!}
  @else
  <form class="form" method="POST" action="{{route('produto.store')}}">
  @endif
{!! csrf_field() !!}
      <div class="form-group">
      <input type="text" name="nome"      placeholder="Nome" class="form-control" value="{{$produto->nome ?? old('nome')}}">
      </div>
      <div class="form-group">
        <input type="text" name="marca"     placeholder="Marca" class="form-control" value="{{$produto->marca ?? old('marca')}}">
      </div>
      <div class="form-group">
         <input type="text" name="preco"     placeholder="Preço" class="form-control" value="{{$produto->preco ?? old('preco')}}">
      </div>
      <div class="form-group">
         <input type="text" name="qtd"       placeholder="Qtd" class="form-control" value="{{$produto->qtd ?? old('qtd')}}">
      </div>
      <div class="form-group">
      <select name="categoria" class="form-control">
          <option>Escolha a categoria</option>
          @foreach ($categorias as $categoria)
      <option value="{{$categoria}}"
         @if(isset($produto) && $produto->categoria == $categoria)
             selected
         @endif
         >{{$categoria}}</option>
          @endforeach
      </select>
      </div>
      <div class="form-group">
      <textarea name="descricao"  placeholder="Descrição" class="form-control" value="{{$produto->descricao ?? old('descricao')}}">{{$produto->descricao ?? old('descricao')}}</textarea>
      </div>
      <br>
      <button class="btn btn-primary">Enviar</button>
  </form>


@endsection
