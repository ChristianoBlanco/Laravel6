﻿@extends('layouts.app')

@section('content')

<h1 class="title-pg">Produtos</h1>

<a href="{{route('produto.create')}}" class="btn btn-btn btn-primary btn-add">
  Cadastrar
</a>
<br><br>
<form action="{{route('search')}}" method="POST" class="form form-inline">
    {{ csrf_field() }}
   <input type="text" name='marca' class="form-control" placeholder="Pesquisar Marca...">

   <button type="submit" class="btn btn-primary">Pesquisar</button>
</form>

  <table width="476" border="0" cellspacing="0" cellpadding="0" class="table table-striped">
  <tr>
    <th>Nome</th>
    <th>Marca</th>
    <th>Preço</th>
    <th>Categoria</th>
    <th>Qtd.</th>
    <th width="100px">Ações</th>
  </tr>
  @foreach($produtos as $produto)
  <tr>
    <td>{{$produto->nome}}</td>
    <td>{{$produto->marca}}</td>
    <td>{{$produto->preco}}</td>
    <td>{{$produto->categoria}}</td>
    <td>{{$produto->qtd}}</td>
    <td>
    <a href="{{route('produto.edit', $produto->id_produto)}}" class="actions edit">
         <span class="glyphicon glyphicon-pencil">Edt </span>
     </a>

     <a href="{{route('produto.show', $produto->id_produto)}}" class="actions delete">
            <span class="glyphicon glyphicon-trash"> Del</span>
     </a>
    </td>
  @endforeach
    </td>
  </tr>

</table>

{!! $produtos->links() !!}

@endsection
