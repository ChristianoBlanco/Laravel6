@extends('layouts.app')

@section('content')

<h1 class="title-pg">
<a href="{{route('produto.index')}}"> << </a>    Produto: {{$produto->nome}}</h1>

<table width="476" border="0" cellspacing="0" cellpadding="0" class="table table-striped">
    <tr>
      <th>Nome</th>
      <th>Marca</th>
      <th>Preço</th>
      <th>Categoria</th>
      <th>Qtd.</th>

    </tr>

    <tr>
      <td>{{$produto->nome}}</td>
      <td>{{$produto->marca}}</td>
      <td>{{$produto->preco}}</td>
      <td>{{$produto->categoria}}</td>
      <td>{{$produto->qtd}}</td>
    </tr>

  </table>
  <p><b>Descrição:</b><br>{{$produto->descricao}}</p>

  <br>
  <hr>
  @if(isset($errors) && count($errors) > 0)

     <div class="alert alert-danger">
       @foreach ($errors->all() as $error )
          <p>{{$error}}</p>
       @endforeach
     </div>

  @endif
  {!! Form::open(['route' =>['produto.destroy', $produto->id_produto], 'method' =>'DELETE']) !!}
      {!! Form::submit("Deletar produto $produto->nome", ['class' => 'btn btn-danger']) !!}
  {!! Form::close() !!}


@endsection
